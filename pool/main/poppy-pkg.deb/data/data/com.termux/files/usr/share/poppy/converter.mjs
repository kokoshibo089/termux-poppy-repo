import fs from 'node:fs';
import path from 'node:path';
import * as mupdf from 'mupdf';
import mammoth from 'mammoth';

// دالة لاستخراج النص من PDF
async function extractPdfText(filePath) {
    try {
        const data = fs.readFileSync(filePath);
        const doc = mupdf.Document.openDocument(data, "application/pdf");
        let text = "";
        const pageCount = doc.countPages();
        
        for (let i = 0; i < pageCount; i++) {
            const page = doc.loadPage(i);
            const pageText = page.toStructuredText("preserve-whitespace").asText();
            text += pageText + "\n";
        }
        return text;
    } catch (error) {
        console.error("خطأ في قراءة PDF:", error.message);
        return "";
    }
}

// دالة لاستخراج النص من Word
async function extractDocxText(filePath) {
    try {
        const result = await mammoth.extractRawText({ path: filePath });
        return result.value;
    } catch (error) {
        console.error("خطأ في قراءة Word:", error.message);
        return "";
    }
}

// الدالة الرئيسية
async function main() {
    const args = process.argv.slice(2); 

    if (args.length < 3) {
        console.log("الاستخدام: node converter.mjs extract <file> <output.txt>");
        return;
    }

    const mode = args[0]; 
    const filePath = args[1];
    const textPath = args[2];
    const ext = path.extname(filePath).toLowerCase();

    if (mode === "extract") {
        let text = "";
        if (ext === ".pdf") {
            text = await extractPdfText(filePath);
        } else if (ext === ".docx") {
            text = await extractDocxText(filePath);
        } else {
            console.log("صيغة الملف غير مدعومة.");
            return;
        }
        
        fs.writeFileSync(textPath, text, 'utf8');
        console.log(`تم استخراج النص إلى: ${textPath}`);
    } else {
        console.log("وضع غير معروف.");
    }
}

main();
